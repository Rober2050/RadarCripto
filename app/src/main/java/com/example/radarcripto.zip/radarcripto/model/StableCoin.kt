package com.example.radarcripto.model

enum class StableCoin {
    USDT,
    USDC,
    DAI
}
