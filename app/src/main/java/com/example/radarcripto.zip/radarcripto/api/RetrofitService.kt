package com.example.radarcripto.api

import com.example.radarcripto.model.DolarData
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET


// Servicio Retrofit que conecta a CriptoYa
object RetrofitService {
    private const val BASE_URL = "https://criptoya.com/api/"

    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val api: CriptoYaApi by lazy {
        retrofit.create(CriptoYaApi::class.java)
    }

    suspend fun obtenerPreciosDolar(): DolarData {
        return api.obtenerPreciosDolar()
    }
}

