

// Archivo: PantallaSimuladorRoi.kt
// Propósito: Simulador de ROI + Comparador entre exchanges + Comparador contra dólar blue
//

 package com.example.radarcripto.ui
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.radarcripto.api.RetrofitService
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch



@Composable
fun PantallaSimuladorRoi(navController: NavHostController) {
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()

    var precioCompraOficial by remember { mutableStateOf("") }
    var precioVentaBlue by remember { mutableStateOf("") }
    var montoInversion by remember { mutableStateOf("1000") }

    var cotizacionOficial by remember { mutableStateOf<Double?>(null) }
    var cotizacionBlue by remember { mutableStateOf<Double?>(null) }
    var errorCarga by remember { mutableStateOf(false) }

    var roiCalculado by remember { mutableStateOf<Double?>(null) }
    var gananciaCalculada by remember { mutableStateOf<Double?>(null) }
    var mensajeOportunidad by remember { mutableStateOf("") }

    var isLoading by remember { mutableStateOf(false) }

    fun calcularAutomaticamente() {
        val compra = precioCompraOficial.toDoubleOrNull() ?: 0.0
        val venta = precioVentaBlue.toDoubleOrNull() ?: 0.0
        val monto = montoInversion.toDoubleOrNull() ?: 0.0

        if (compra > 0 && venta > 0 && monto > 0) {
            val roi = ((venta - compra) / compra) * 100
            val ganancia = (venta - compra) * (monto / compra)

            roiCalculado = roi
            gananciaCalculada = ganancia

            mensajeOportunidad = if (roi > 0) {
                "✅ Oportunidad: Conviene comprar Oficial y vender Blue."
            } else {
                "Hoy no hay diferencia significativa."
            }
        } else {
            mensajeOportunidad = "❌ Ingresá datos válidos para calcular."
        }
    }

    LaunchedEffect(Unit) {
        try {
            val precios = RetrofitService.obtenerPreciosDolar()

            if (precios.oficial.price > 0 && precios.blue.price > 0) {
                cotizacionOficial = precios.oficial.price
                cotizacionBlue = precios.blue.price

                precioCompraOficial = cotizacionOficial!!.toInt().toString()
                precioVentaBlue = cotizacionBlue!!.toInt().toString()

                calcularAutomaticamente()
                errorCarga = false
            } else {
                errorCarga = true
            }
        } catch (e: Exception) {
            e.printStackTrace()
            errorCarga = true
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0A0E25), Color(0xFF0B0F2D))
                )
            )
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Simulador de ROI",
                style = MaterialTheme.typography.headlineMedium,
                color = Color(0xFFD0D0FF)
            )

            when {
                errorCarga -> {
                    Text(
                        text = "❌ No se pudo cargar precios actuales.",
                        color = Color.Red
                    )
                }
                cotizacionOficial == null || cotizacionBlue == null -> {
                    Text(
                        text = "Cargando cotizaciones...",
                        color = Color.LightGray,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                else -> {
                    Text(
                        text = "Oficial: \$${cotizacionOficial?.toInt()} - Blue: \$${cotizacionBlue?.toInt()}",
                        color = Color.White,
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }

            OutlinedTextField(
                value = precioCompraOficial,
                onValueChange = { precioCompraOficial = it },
                label = { Text("Precio Compra Oficial", color = Color.White) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    cursorColor = Color.White,
                    focusedBorderColor = Color(0xFF4D9BFF),
                    unfocusedBorderColor = Color.Gray,
                    focusedLabelColor = Color(0xFF4D9BFF),
                    unfocusedLabelColor = Color.Gray
                )
            )

            OutlinedTextField(
                value = precioVentaBlue,
                onValueChange = { precioVentaBlue = it },
                label = { Text("Precio Venta Blue", color = Color.White) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    cursorColor = Color.White,
                    focusedBorderColor = Color(0xFF4D9BFF),
                    unfocusedBorderColor = Color.Gray,
                    focusedLabelColor = Color(0xFF4D9BFF),
                    unfocusedLabelColor = Color.Gray
                )
            )

            OutlinedTextField(
                value = montoInversion,
                onValueChange = { montoInversion = it },
                label = { Text("Monto a Invertir en Pesos", color = Color.White) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedContainerColor = Color.Transparent,
                    unfocusedContainerColor = Color.Transparent,
                    cursorColor = Color.White,
                    focusedBorderColor = Color(0xFF4D9BFF),
                    unfocusedBorderColor = Color.Gray,
                    focusedLabelColor = Color(0xFF4D9BFF),
                    unfocusedLabelColor = Color.Gray
                )
            )

            Button(
                onClick = {
                    scope.launch {
                        isLoading = true
                        delay(800)
                        calcularAutomaticamente()
                        isLoading = false
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF4D9BFF),
                    contentColor = Color.White
                ),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 3.dp
                    )
                } else {
                    Text("Calcular")
                }
            }

            roiCalculado?.let {
                Text(
                    text = "ROI estimado: ${String.format("%.2f", it)}%",
                    color = if (it > 0) Color.Green else Color.Gray,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            gananciaCalculada?.let {
                Text(
                    text = "Ganancia estimada: \$${String.format("%.2f", it)}",
                    color = if (it > 0) Color.Green else Color.Gray,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            if (mensajeOportunidad.isNotEmpty()) {
                Text(
                    text = mensajeOportunidad,
                    color = if (roiCalculado != null && roiCalculado!! > 0) Color.Green else Color.Gray,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }
        }
    }
}
