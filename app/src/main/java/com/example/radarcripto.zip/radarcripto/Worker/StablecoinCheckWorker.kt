package com.example.radarcripto.worker

import android.Manifest
import android.content.Context
import androidx.annotation.RequiresPermission
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.example.radarcripto.api.RetrofitService
import com.example.radarcripto.datastore.DataStoreManager
import com.example.radarcripto.util.NotificacionesUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.first
import java.text.DecimalFormat

class StablecoinCheckWorker(
    private val context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    override suspend fun doWork(): Result {
        val roiObjetivo = DataStoreManager.getRoiObjetivo(context).first()

        return try {
            val precios = withContext(Dispatchers.IO) {
                RetrofitService.obtenerPreciosDolar()
            }

            val precioCompra = precios.oficial.price
            val precioVenta = precios.blue.price

            if (precioCompra > 0 && precioVenta > 0) {
                val roi = ((precioVenta - precioCompra) / precioCompra) * 100
                val formatter = DecimalFormat("#.##")

                if (roi >= roiObjetivo) {
                    NotificacionesUtils.mostrarNotificacion(
                        context,
                        "Oportunidad detectada: ROI del ${formatter.format(roi)}%"
                    )
                }
            }

            Result.success()

        } catch (e: Exception) {
            e.printStackTrace()
            Result.failure()
        }
    }
}
