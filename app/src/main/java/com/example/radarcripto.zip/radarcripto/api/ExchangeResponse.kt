package com.example.radarcripto.api

 data class ExchangeResponse(
     val totalBid: Double,
     val totalAsk: Double
 )